﻿
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh" lang="zh">
    <head>
        <title>404 - 页面未找到</title>
    </head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style type="text/css">
        body {
            text-align: center;
            font-family: Arial;
            padding-top: 200px;
        }
    </style>
    <body>
        <h1>错误: 404</h1><b>页面未找到</b><br />抱歉，我们在您输入的网址上找不到任何内容。该页面可能以前已存在但不再有效。</body>
</html>